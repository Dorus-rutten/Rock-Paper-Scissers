testing setup and requirement files for ez setup
# Rock-Paper-Scissers
This is a code that lets u play rock paper scissers against an ai using your webcam.

to use this code u need some libs.
i will make it ez for u to do but form now its just the reposetary
